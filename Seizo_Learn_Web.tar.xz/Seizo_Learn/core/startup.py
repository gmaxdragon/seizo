"""Local-only readiness checks and per-folder instance discovery (no secrets)."""
from __future__ import annotations
import json
import os
from pathlib import Path
import secrets
import time
import urllib.request


def health(port: int, timeout: float = 2.0) -> dict:
    if type(port) is not int or not 1 <= port <= 65535:
        return {}
    try:
        # Do not send localhost requests through an environment proxy.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f'http://127.0.0.1:{port}/healthz', timeout=timeout) as response:
            if response.status != 200:
                return {}
            value = json.loads(response.read(4097))
            return value if isinstance(value, dict) and value.get('app') == 'SeizoLearn' else {}
    except (OSError, ValueError):
        return {}


def wait_ready(port: int, instance: str, deadline: float = 15.0) -> bool:
    end = time.monotonic() + deadline
    while time.monotonic() < end:
        state = health(port, timeout=min(1.0, max(.1, end-time.monotonic())))
        if state.get('ready') is True and secrets.compare_digest(str(state.get('instance', '')), instance):
            return True
        time.sleep(.1)
    return False


def write_instance(folder: Path, port: int, instance: str, build: str) -> None:
    folder = Path(folder)
    record = {'port':port, 'instance':instance, 'build':build, 'pid':os.getpid()}
    temporary = folder / ('.server-' + secrets.token_hex(6) + '.tmp')
    try:
        temporary.write_text(json.dumps(record), encoding='utf-8')
        os.replace(temporary, folder / '.running.json')
    finally:
        temporary.unlink(missing_ok=True)


def existing_url(folder: Path, build: str) -> str | None:
    try:
        record = json.loads((Path(folder) / '.running.json').read_text(encoding='utf-8'))
        if record.get('build') != build:
            return None
        state = health(record.get('port'))
        if state.get('ready') is True and secrets.compare_digest(str(record.get('instance', '')), str(state.get('instance', ''))):
            return f"http://127.0.0.1:{record['port']}/?build={build}"
    except (OSError, ValueError, AttributeError):
        pass
    return None


def clear_instance(folder: Path, instance: str) -> None:
    file = Path(folder) / '.running.json'
    try:
        record = json.loads(file.read_text(encoding='utf-8'))
        if record.get('instance') == instance:
            file.unlink()
    except (OSError, ValueError):
        pass
