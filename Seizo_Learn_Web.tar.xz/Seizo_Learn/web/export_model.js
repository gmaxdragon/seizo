/* Exports the actual solid scene at its current pose. No screenshots, generated
 * images, motor commands, networking or hidden calibration. glTF 2.0, Y-up/metres.
 * All runtime part geometry and group transforms come from the shared Renderer.
 */
export function createModelGLB(renderer, config, pose) {
  const doc={asset:{version:'2.0',generator:'Seizo Studio actual solid model export'},
    scene:0,scenes:[{name:'Seizo photo-reconstructed assembly',nodes:[0]}],
    nodes:[{name:'Seizo visual reconstruction (not fabrication CAD)',rotation:[-Math.SQRT1_2,0,0,Math.SQRT1_2],scale:[.001,.001,.001],children:[],
      extras:{model_id:config.model_id,visual_revision:config.visual_revision,pose_degrees:{...pose},source_units:'estimated millimetres',simulation_only:true,physical_motion:false,calibrated:false}}],
    meshes:[],materials:[],accessors:[],bufferViews:[],buffers:[{byteLength:0}]};
  const chunks=[],geoMap=new Map(),materialMap=new Map(),meshMap=new Map(),groupMap=new Map();let byteLength=0;
  function accessor(data,type,bounds=false){
    const values=new Float32Array(data);
    if(!values.length||!Array.from(values).every(Number.isFinite))throw Error('Cannot export invalid mesh data.');
    const view=doc.bufferViews.length;doc.bufferViews.push({buffer:0,byteOffset:byteLength,byteLength:values.byteLength,target:34962});
    chunks.push(new Uint8Array(values.buffer));byteLength+=values.byteLength;
    const a={bufferView:view,componentType:5126,count:values.length/3,type};
    if(bounds){a.min=[Infinity,Infinity,Infinity];a.max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<values.length;i++){let k=i%3;a.min[k]=Math.min(a.min[k],values[i]);a.max[k]=Math.max(a.max[k],values[i]);}}
    const index=doc.accessors.length;doc.accessors.push(a);return index;
  }
  for(const part of renderer.parts){
    if(part.floor||['environment','target','markers'].includes(part.category)||part.visible===false)continue;
    if(renderer.hidden.has(part.category)||(part.group==='mast'&&renderer.hidden.has('camera')))continue;
    const data=renderer.meshes[part.geometry]?.data;if(!data)throw Error('Missing source geometry '+part.geometry);
    if(!geoMap.has(part.geometry))geoMap.set(part.geometry,{POSITION:accessor(data.p,'VEC3',true),NORMAL:accessor(data.n,'VEC3')});
    const materialKey=JSON.stringify([part.color,part.metal||0,part.rough||.5]);
    if(!materialMap.has(materialKey)){
      materialMap.set(materialKey,doc.materials.length);
      doc.materials.push({name:part.name+' material',doubleSided:true,pbrMetallicRoughness:{baseColorFactor:[...part.color.map(c=>Math.pow(c,2.2)),1],metallicFactor:part.metal||0,roughnessFactor:part.rough||.5}});
    }
    const material=materialMap.get(materialKey),meshKey=part.geometry+'|'+material;
    if(!meshMap.has(meshKey)){
      meshMap.set(meshKey,doc.meshes.length);doc.meshes.push({name:part.geometry,primitives:[{attributes:geoMap.get(part.geometry),material,mode:4}]});
    }
    if(!groupMap.has(part.group)){
      const matrix=Array.from(renderer.groups[part.group]||[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);
      if(!matrix.every(Number.isFinite))throw Error('Invalid model transform.');
      const index=doc.nodes.length;groupMap.set(part.group,index);doc.nodes.push({name:'Seizo frame / '+part.group,matrix,children:[]});doc.nodes[0].children.push(index);
    }
    const index=doc.nodes.length;doc.nodes.push({name:(part.name||part.geometry)+' ['+index+']',mesh:meshMap.get(meshKey),matrix:Array.from(part.local),extras:{assembly:part.category}});
    doc.nodes[groupMap.get(part.group)].children.push(index);
  }
  doc.buffers[0].byteLength=byteLength;
  let json=new TextEncoder().encode(JSON.stringify(doc));const jsonLen=(json.length+3)&~3,binLen=(byteLength+3)&~3;
  const result=new ArrayBuffer(12+8+jsonLen+8+binLen),view=new DataView(result),u8=new Uint8Array(result);
  view.setUint32(0,0x46546c67,true);view.setUint32(4,2,true);view.setUint32(8,result.byteLength,true);
  view.setUint32(12,jsonLen,true);view.setUint32(16,0x4e4f534a,true);u8.fill(32,20,20+jsonLen);u8.set(json,20);
  let at=20+jsonLen;view.setUint32(at,binLen,true);view.setUint32(at+4,0x004e4942,true);at+=8;
  for(const chunk of chunks){u8.set(chunk,at);at+=chunk.length;}
  return result;
}
