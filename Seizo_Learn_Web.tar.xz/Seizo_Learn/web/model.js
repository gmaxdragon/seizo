/* Seizo Studio R3: ACTUAL mesh assembly. Fuller original profiles + close-up details.
   No calibrated masses, real motor mapping or physical execution implied. */
import {ident,mul,T,S,RX,RY,RZ,compose,point,V} from './renderer.js';
import {DEG,DEFAULT_DIMS,fk} from './kinematics.js';
export {DEG,DEFAULT_DIMS,fk};
export const COLORS={gray:[.38,.405,.42],edge:[.49,.515,.53],dark:[.075,.085,.10],black:[.035,.042,.05],silver:[.64,.70,.73],purple:[.46,.38,.66],red:[.79,.09,.14],orange:[.98,.37,.085],gold:[.72,.57,.27],wood:[.75,.61,.44],white:[.9,.92,.93],pcb:[.08,.29,.21],wireRed:[.7,.05,.06],yellow:[.87,.7,.11],blue:[.08,.29,.58],green:[.05,.47,.29]};
function cylBetween(a,b,r){let z=V.norm(V.sub(b,a)),aux=Math.abs(z[2])<.95?[0,0,1]:[0,1,0],x=V.norm(V.cross(aux,z)),y=V.cross(z,x);let m=new Float32Array([x[0],x[1],x[2],0,y[0],y[1],y[2],0,z[0],z[1],z[2],0,...a,1]);return mul(m,S(r,r,Math.hypot(...V.sub(b,a))))}
function tube(points,r=1.2){let p=[],n=[],path=[];const pts=points.map(a=>a.slice());for(let k=0;k<pts.length-1;k++){let p0=pts[Math.max(0,k-1)],p1=pts[k],p2=pts[k+1],p3=pts[Math.min(pts.length-1,k+2)];for(let j=0;j<6;j++){let t=j/6;path.push(p1.map((_,i)=>.5*(2*p1[i]+(-p0[i]+p2[i])*t+(2*p0[i]-5*p1[i]+4*p2[i]-p3[i])*t*t+(-p0[i]+3*p1[i]-3*p2[i]+p3[i])*t*t*t)))}}path.push(pts.at(-1));let rings=[];for(let i=0;i<path.length;i++){let z=V.norm(V.sub(path[Math.min(path.length-1,i+1)],path[Math.max(0,i-1)])),aux=Math.abs(z[2])>.85?[0,1,0]:[0,0,1],a=V.norm(V.cross(z,aux)),b=V.cross(z,a);rings.push(Array.from({length:8},(_,j)=>{let th=j*Math.PI/4,normal=a.map((x,k)=>x*Math.cos(th)+b[k]*Math.sin(th));return {p:normal.map((x,k)=>path[i][k]+x*r),n:normal}}))}for(let i=0;i<rings.length-1;i++)for(let j=0;j<8;j++){for(let[u,v]of [[i,j],[i+1,j],[i+1,(j+1)%8],[i,j],[i+1,(j+1)%8],[i,(j+1)%8]]){p.push(...rings[u][v].p);n.push(...rings[u][v].n)}}return{p,n}}
function ribbon(points,width=5,thickness=.9){
 const vertices=[],normals=[];
 const tri=(a,b,c,n)=>{vertices.push(...a,...b,...c);normals.push(...n,...n,...n)};
 for(let i=0;i<points.length-1;i++){
  const a=points[i],b=points[i+1],direction=V.norm(V.sub(b,a));
  let face=Math.abs(direction[1])>.85?[0,0,1]:[0,1,0];
  const across=V.norm(V.cross(direction,face));face=V.norm(V.cross(across,direction));
  const ring=q=>[[1,1],[-1,1],[-1,-1],[1,-1]].map(([u,v])=>q.map((x,k)=>x+across[k]*u*width/2+face[k]*v*thickness/2));
  const A=ring(a),B=ring(b);
  for(let k=0;k<4;k++){let j=(k+1)%4,n=V.norm(V.cross(V.sub(B[k],A[k]),V.sub(A[j],A[k])));tri(A[k],B[k],A[j],n);tri(A[j],B[k],B[j],n);}
  tri(A[0],A[1],A[2],direction.map(v=>-v));tri(A[0],A[2],A[3],direction.map(v=>-v));tri(B[0],B[2],B[1],direction);tri(B[0],B[3],B[2],direction);
 }
 return {p:vertices,n:normals};
}
export function buildModel(renderer,options={}){let R=renderer,id=0;const all=[];function add(geo,group,m,color,category,name,extra={}){let c=COLORS[color]||color;let defaults={rough:.50,metal:0,grain:0};if(['gray','purple','red','black'].includes(color))defaults={rough:.57,metal:0,grain:1};if(['gold','silver'].includes(color))defaults={rough:.29,metal:.72,grain:0};if(color==='orange')defaults={rough:.73,metal:0,grain:0};let obj={geometry:geo,group,local:m,color:c,category,name,...defaults,...extra};R.add(obj);all.push(obj);return obj}
const box=(g,pos,size,col,cat,name='')=>add('roundbox',g,compose(T(...pos),S(...size)),col,cat,name);
const cylinder=(g,pos,r,h,col,cat,rot=ident(),name='')=>add('cylinder',g,compose(T(...pos),rot,S(r,r,h)),col,cat,name);
const rod=(g,a,b,r,col,cat)=>add('cylinder',g,cylBetween(a,b,r),col,cat,'Link rod');
const bolt=(g,x,y,z,r=2.8,cat='arm',orientation=null)=>{
 const rot=orientation||RX(y<0?Math.PI/2:-Math.PI/2),frame=compose(T(x,y,z),rot);
 add('washer',g,compose(frame,S(r,r,r*.6)),'silver',cat,'Steel pivot washer',{metal:.72,rough:.27});
 add('socketHead',g,compose(frame,T(0,0,r*.12),S(r*.67,r*.67,r*.67)),'silver',cat,'Recessed socket fastener',{metal:.78,rough:.24});
};
const wire=(g,points,r,col,cat)=>{let k='wire'+(++id);R.meshes[k]=R.mesh(tube(points,r));return add(k,g,ident(),col,cat,'Cable')};
function motor(g,pos,cat,rot=RX(Math.PI/2)){
 const frame=compose(T(...pos),rot);
 add('roundbox',g,compose(frame,T(0,0,-23),S(41.2,41.2,38)),'dark',cat,'NEMA17 motor stack',{metal:.35,rough:.44,grain:0});
 for(let z of [-45,-2])add('motorcap',g,compose(frame,T(0,0,z)),z===-45?'black':'silver',cat,'Beveled motor end cap',{metal:z===-45?.12:.65,rough:.36,grain:0});
 for(let z of [-37,-32,-27,-22,-17,-12]){
  // Inset steel seams; no extra cover replacing the photographed motor body.
  for(let sign of [-1,1]){
   add('box',g,compose(frame,T(sign*20.65,0,z),S(.10,35,.18)),[.22,.24,.25],cat,'Motor lamination seam',{metal:.55,rough:.4});
  }
 }
 add('cylinder',g,compose(frame,T(0,0,0),S(11,11,2)),'silver',cat,'Motor bearing boss');
 add('cylinder',g,compose(frame,T(0,0,2),S(2.5,2.5,17)),'silver',cat,'Motor shaft');
 for(let x of [-15.5,15.5])for(let y of [-15.5,15.5]){
  add('socketHead',g,compose(frame,T(x,y,1.1),S(2.3,2.3,2.3)),'dark',cat,'Motor front socket screw',{metal:.55,grain:0});
  add('socketHead',g,compose(frame,T(x,y,-48.2),RX(Math.PI),S(2.3,2.3,2.3)),'silver',cat,'Motor rear silver fastener');
 }
 add('roundbox',g,compose(frame,T(0,-21,-32),S(12,4,7)),'black',cat,'Stepper wire strain relief');
}

function strap(g,points,width=5){let key='strap'+(++id);R.meshes[key]=R.mesh(ribbon(points,width));return add(key,g,ident(),'orange','shoulder','Flat orange retaining strap',{rough:.83});}
// Neutral studio surface; not represented as the user's actual desktop.
add('box','world',compose(T(0,0,-11),S(6000,6000,12)),[.76,.8,.84],'environment','Studio floor',{floor:true,rough:.85});
// Purple printed base, rotation bearing, base-drive stepper and exposed toothed ring.
add('baseFoot','base',ident(),'purple','base','Fixed purple chamfered foot');
for(let x of [-64,64])for(let y of [-60,60]){cylinder('base',[x,y,5],4,3,'silver','base');cylinder('base',[x,y,-5],8,3,'dark','base')}
add('gear72','base',T(0,0,7),'purple','base','Fixed purple toothed base ring');
cylinder('base',[0,0,21],59,8,'purple','base');
cylinder('base',[0,0,28],51,11,'purple','base');
cylinder('base',[0,0,39],48,4,'gray','base');
motor('base',[-49,-56,56],'base',RX(Math.PI));
add('gear16','base',compose(T(-49,-56,20),S(.9,.9,1)),'dark','base','Base motor pinion');
box('yaw',[0,0,47],[91,86,13],'gray','base','Rotating shoulder deck');
cylinder('yaw',[0,0,50],40,52,'gray','base');
for(let side of [-1,1])add('shoulderCheek','yaw',compose(T(0,side*30,70),RX(Math.PI/2)),'gray','shoulder','Hollow shoulder support cheek');
add('saddle','yaw',T(0,0,99),'gray','base','Open annular shoulder saddle');
for(let a of [0,60,120,180,240,300]){let t=a*DEG;box('yaw',[Math.cos(t)*37,Math.sin(t)*37,94],[9,7,24],'gray','base','Printed saddle support rib');}
for(let side of [-1,1]){
 add('flangedBearing','yaw',compose(T(0,side*43,135),RX(side<0?Math.PI/2:-Math.PI/2),S(10.5,10.5,7)),'silver','shoulder','Shoulder flange bearing');
}
// Wide side mount with the two shoulder motors visible in the photographs.
for(let side of [-1,1]){
 box('yaw',[0,side*34,119],[43,11,47],'gray','shoulder','Bearing mount');
 motor('yaw',[0,side*50,120],'shoulder',RX(side<0?-Math.PI/2:Math.PI/2));
 add('gear48',side<0?'jointGearA':'jointGearB',RX(Math.PI/2),'dark','shoulder','Large joint spur gear');
 add('gear16',side<0?'pinionA':'pinionB',RX(Math.PI/2),'dark','shoulder','Joint spur pinion');
 // Orange loops are retaining bands, not simulated timing belts.
 // Two continuous flat elastic loops, not diagonal X shapes across the cover.
 for(let y of [side*74,side*88])add('retainingBand','yaw',T(0,y,120),'orange','shoulder','Flat orange retaining strap',{rough:.77,grain:0});
 for(let x of [-15,15])bolt('yaw',x,side*47,136,3.5,'shoulder');
}
rod('yaw',[0,-50,135],[0,50,135],6,'silver','shoulder');
// Hollow structural cheeks and independent leveling bars.
// The bar lengths are visual estimates; all moving frames share the same FK.
for(let side of [-1,1]){
 add('upper','upper',compose(T(0,side*26,0),RX(Math.PI/2)),'gray','upper','Open-window upper cheek');
 rod('upperTie',[0,side*36,0],[145,side*36,0],2.5,'edge','upper');
 for(let group of ['shoulderLevel','elbowLevel']){
  box(group,[0,side*36,13.5],[9,6,27],'gray','upper','Upright parallel-link pivot');
  for(let z of [0,27])bolt(group,0,side*40,z,3.4,'upper');
 }
 for(let x of [0,145]){cylinder('upper',[x,side*30,0],8.2,4,'edge','upper',RX(Math.PI/2));bolt('upper',x,side*34,0,3.8,'upper');}
}
rod('upper',[145,-39,0],[145,39,0],4.7,'silver','upper');
for(let side of [-1,1])for(let x of [0,145]){
 const rot=RX(side<0?Math.PI/2:-Math.PI/2);
 add('flangedBearing','upper',compose(T(x,side*32,0),rot,S(8.8,8.8,3.5)),'edge','upper','Printed bushing with through bore',{rough:.4,grain:1});
 bolt('upper',x,side*35,0,4.1,'upper');
}
for(let side of [-1,1]){
 add('forearm','forearm',compose(T(0,side*15,0),RX(Math.PI/2)),'gray','forearm','Hollow tapered forearm beam');
 rod('forearmTie',[0,side*32,0],[220,side*32,0],2.8,'edge','forearm');
 for(let group of ['elbowLevel','wrist']){
  box(group,[0,side*32,15],[9,6,30],'gray','forearm','Leveling-rod end plate');
  for(let z of [0,30])bolt(group,0,side*36,z,3.3,'forearm');
 }
}
for(let x of [0,108,218])box('forearm',[x,0,0],[11,34,x===0?25:16],'gray','forearm','Forearm cross rib');
rod('forearm',[0,-34,0],[0,34,0],5,'silver','forearm');
rod('forearm',[220,-31,0],[220,31,0],4.5,'silver','forearm');
wire('forearm',[[0,23,18],[60,26,19],[160,24,11],[218,27,3]],1.2,'black','wiring');
wire('forearm',[[0,20,18],[80,22,19],[160,21,11],[217,24,2]],.75,'wireRed','wiring');
// Photo-refined wrist: distinct adapter, camera/servo housing and white cover.
box('wrist',[-6,0,0],[23,45,18],'gray','tool','Wrist crosshead');
box('wrist',[9,0,2],[23,43,31],'wood','tool','Wrist adapter');
box('wrist',[6,0,26],[48,23,16],'black','tool','Wrist camera support');
cylinder('wrist',[29,0,25],5,3,'dark','tool',RY(Math.PI/2));
cylinder('wrist',[32,0,25],3.1,1,'blue','tool',RY(Math.PI/2));
box('wrist',[25,0,7],[20,24,25],[.50,.58,.62],'tool','Translucent-servo housing representation');
box('wrist',[25,-12.4,10],[12,1.2,4],[.65,.14,.36],'tool','Magenta servo insert');
box('wrist',[25,12.4,10],[12,1.2,4],[.65,.14,.36],'tool','Magenta servo insert');
add('wristCover','wrist',T(40,0,7),'white','tool','Stepped hollow white wrist cover',{rough:.5,grain:1});
box('wrist',[51,0,-9],[30,44,5],'wood','tool','Gripper root backing');
add('palm','wrist',T(55,0,-5),'black','tool','Gripper root plate');
for(let side of [-1,1]){
 add('cylinder','wrist',compose(T(53,side*11,-4),S(5.7,5.7,5)),'dark','tool','Gripper gear hub');
 bolt('wrist',51,side*19,-8,2.5,'tool');
}

// Black open jaws and diagonal parallel bars follow the submitted close-up.
const linkage=(a,b,z=1)=>{let dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy);return add('gripperLink','wrist',compose(T((a[0]+b[0])/2,(a[1]+b[1])/2,z),RZ(Math.atan2(dy,dx)),S(L/50,1,1)),'black','tool','Rounded gripper parallelogram bar');};
for(let side of [-1,1]){
 const root=[53,side*12],outer=[99,side*39],innerRoot=[64,side*3],innerTip=[108,side*29];
 add('gripperGear','wrist',T(53,side*11,-.5),'dark','tool','Small meshing gripper gear');
 linkage(root,outer,2);linkage(innerRoot,innerTip,-1.5);
 add('finger','wrist',compose(T(99,side*39,-2),S(1,side,1)),'black','tool','Long hollow triangular gripper jaw');
 for(let [x,y]of [root,outer,innerRoot]){
  add('washer','wrist',compose(T(x,y,6.4),S(5,5,5)),'gold','tool','Brass pivot washer',{metal:.68,rough:.29});
  add('socketHead','wrist',compose(T(x,y,7.45),S(2.1,2.1,1.8)),'gold','tool','Brass recessed pivot head',{metal:.65,rough:.32});
 }
 for(let [x,y]of [[108,side*29],[120,side*24]]){
  add('washer','wrist',compose(T(x,y,3.4),S(3.4,3.4,4)),'silver','tool','Jaw linkage fastener',{metal:.7});
  add('socketHead','wrist',compose(T(x,y,4.3),S(1.7,1.7,1.7)),'silver','tool','Jaw socket fastener');
 }
 box('wrist',[173,side*3.5,-.2],[4.5,2,4.5],'orange','tool','Thin orange fingertip pad');
}
// Small exposed interface board and actual loose colored tool wires.
box('wrist',[41,-48,-6],[47,18,2],'pcb','electronics','Tool interface PCB');
box('wrist',[42,-39,-3],[44,3.6,3],'black','electronics','Header plastic carrier');
for(let x=22;x<62;x+=3){box('wrist',[x,-38,0],[.9,.9,7],'gold','electronics','Header pin');cylinder('wrist',[x,-47,-4.8],1.1,.6,'silver','electronics');}
box('wrist',[40,-49,-4],[13,8,1.3],'dark','electronics','Tool board IC package');
for(let i=0;i<5;i++)box('wrist',[24+i*6,-54,-4],[2.5,1.6,.7],'white','electronics','Tool board passive component');
for(let [i,color]of ['wireRed','yellow','blue','green','black'].entries()){
 wire('wrist',[[25,-16+i*2,7],[37,-37-i*2,17],[72,-36-i*2,7],[96,sideOffset(i),-2]],.6,color,'wiring');
}
function sideOffset(i){return -15+i*5}
// A separate red-and-purple camera mast, not an extra robot link.
box('mast',[0,0,5],[91,93,17],'red','camera','Camera tower foot');
box('mast',[0,0,139],[24,26,260],'purple','camera','Purple inner camera post');
box('mast',[0,0,104],[37,40,168],'red','camera','Lower red sleeve');
for(let y of [-23,23])add('mastBracket','mast',compose(T(-14,y,179),RX(Math.PI/2),S(.72,.82,1)),'red','camera','Open triangular camera bracket');
rod('mast',[6,-25,365],[6,25,365],4,'silver','camera');
box('mast',[18,0,402],[25,29,94],'purple','camera','Upper camera link');
box('mast',[18,0,452],[49,41,48],'red','camera','Camera saddle');
box('mast',[44,0,451],[2,23,27],'purple','camera','Purple saddle inset');
box('mast',[18,0,479],[53,34,10],'dark','camera','Webcam pivot');
box('mast',[18,0,494],[34,94,26],'edge','camera','Overhead BRIO camera housing');
box('mast',[34,0,494],[2,88,23],'black','camera','Wide webcam glass face');
for(let yy of [-26,26])cylinder('mast',[35.3,yy,494],1.6,.5,'dark','camera',RY(Math.PI/2));
box('mast',[42,0,452],[2,28,27],'purple','camera','Purple camera saddle insert');

cylinder('mast',[35,0,494],8,2,'dark','camera',RY(Math.PI/2));
cylinder('mast',[37,0,494],4.4,1.5,'blue','camera',RY(Math.PI/2));
wire('mast',[[5,18,486],[-10,26,405],[20,40,268],[0,36,117],[-25,35,15],[-77,23,9]],2.5,'black','wiring');
for(let [i,color]of ['wireRed','yellow','black'].entries()){
 wire('mast',[[30,18+i*3,487],[25,26+i*3,438],[13,32+i*3,316],[3,32+i*3,199],[-12,30+i*3,31],[-71,24+i*3,11]],.75,color,'wiring');
}
for(let z of [111,233,400])box('mast',[3,35,z],[17,2.6,3],'black','camera','Camera cable tie');
// Stationary twin-transducer sensor in its white bracket, visible in the new photo.
box('mast',[38,0,127],[42,57,28],'white','electronics','White ultrasonic bracket');
box('mast',[48,0,143],[26,49,2],'pcb','electronics','Ultrasonic PCB');
for(let side of [-1,1]){
 cylinder('mast',[63,side*13,145],8,7,'silver','electronics',RY(Math.PI/2));
 cylinder('mast',[70.3,side*13,145],6,1,'dark','electronics',RY(Math.PI/2));
 add('washer','mast',compose(T(71.3,side*13,145),RY(Math.PI/2),S(7.2,7.2,3)),'silver','electronics','Ultrasonic rolled rim');
}
// Restrained context: nearby USB hub, not an invented finished electronics enclosure.
box('world',[-20,-143,8],[151,26,16],'black','electronics','USB hub');
for(let x=-82;x<42;x+=23){box('world',[x,-142,17],[15,9,1.8],'silver','electronics','USB port');box('world',[x,-142,18],[11,5,1.2],'blue','electronics','USB contact')}
for(let [i,col]of ['white','white','black'].entries())wire('world',[[-55+i*28,-142,17],[-85+i*17,-109,45],[-90+i*18,-65,59],[-63+i*16,-48,61]],2.3,col,'wiring');
// Optional marker tiles. Attachment offsets are estimates, not a calibrated camera registration.
function tag(g,pos,id,bits){let items=[];items.push(box(g,pos,[52,52,.8],'white','markers','Marker '+id));for(let row=0;row<6;row++)for(let col=0;col<6;col++){let black=row===0||row===5||col===0||col===5||bits[(row-1)*4+col-1]===0;if(black)items.push(box(g,[pos[0]+(col-2.5)*(40/6),pos[1]+(2.5-row)*(40/6),pos[2]+.6],[40/6,40/6,.3],'black','markers','Marker '+id));}return items}
tag('wrist',[10,0,35],10,[1,1,1,1,1,0,0,1,1,0,0,1,0,0,0,1]);
tag('forearm',[75,-20,22],11,[0,0,0,1,0,0,0,1,1,0,1,0,0,1,1,1]);
let target=add('ring','target',S(17,17,5),'orange','target','Target ring',{rough:.32});
let tooltip=cylinder('toolmarker',[0,0,0],3,4,'orange','target');
R.hidden.add('markers');R.hidden.add('target');
if(options.armOnly){
 const keep=p=>!p.floor && p.group!=='mast' && p.group!=='world' && p.category!=='camera';
 R.parts=R.parts.filter(keep);
 for(let i=all.length-1;i>=0;i--)if(!keep(all[i]))all.splice(i,1);
}
return {
 parts:all,
 update(pose,dims=DEFAULT_DIMS,explode=0){
  const yaw=pose.base*DEG,a=pose.shoulder*DEG,b=pose.forearm*DEG;
  const base=compose(T(0,0,explode*25),RZ(yaw));
  const e=[dims.upper*Math.cos(a),0,dims.shoulder_height+dims.upper*Math.sin(a)];
  const w=[e[0]+dims.forearm*Math.cos(b),0,e[2]+dims.forearm*Math.sin(b)];
  R.groups.world=ident();R.groups.base=ident();R.groups.turntable=RZ(yaw);R.groups.yaw=base;
  R.groups.jointGearA=compose(base,T(0,-40,135),RY(-a));
  R.groups.jointGearB=compose(base,T(0,40,135),RY(-b));
  R.groups.pinionA=compose(base,T(26,-41,111),RY(a*3));
  R.groups.pinionB=compose(base,T(26,41,111),RY(b*3));
  R.groups.upper=compose(base,T(0,0,dims.shoulder_height+explode*30),RY(-a),S(dims.upper/145,1,1));
  R.groups.upperTie=compose(base,T(0,0,dims.shoulder_height+27+explode*30),RY(-a),S(dims.upper/145,1,1));
  R.groups.shoulderLevel=compose(base,T(0,0,dims.shoulder_height+explode*30));
  R.groups.elbowLevel=compose(base,T(e[0]+explode*30,0,e[2]+explode*60));
  R.groups.forearm=compose(base,T(e[0]+explode*30,0,e[2]+explode*60),RY(-b),S(dims.forearm/220,1,1));
  R.groups.forearmTie=compose(base,T(e[0]+explode*30,0,e[2]+30+explode*60),RY(-b),S(dims.forearm/220,1,1));
  R.groups.wrist=compose(base,T(w[0]+explode*60,0,w[2]+explode*100));
  R.groups.mast=T(-139,100,0);
  const k=fk(pose,dims);R.groups.toolmarker=T(...k.tool);R.dirty=true;return k;
 },
 setTarget(p){R.groups.target=T(p[0],p[1],p[2]);R.hidden.delete('target');R.dirty=true},
 setTargetState(ok=true){target.color=ok?COLORS.orange:[.85,.12,.13];R.dirty=true}
};
}
