/* Offline WebGL2 mechanical renderer. No CDN, no network, no motion interfaces. */
export const V={sub:(a,b)=>a.map((v,i)=>v-b[i]),add:(a,b)=>a.map((v,i)=>v+b[i]),dot:(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm:a=>{let l=Math.hypot(...a)||1;return a.map(v=>v/l)}};
export function ident(){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])}
export function mul(a,b){let o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o}
export function T(x=0,y=0,z=0){let m=ident();m[12]=x;m[13]=y;m[14]=z;return m}
export function S(x=1,y=x,z=x){let m=ident();m[0]=x;m[5]=y;m[10]=z;return m}
export function RX(a){let m=ident(),c=Math.cos(a),s=Math.sin(a);m[5]=c;m[6]=s;m[9]=-s;m[10]=c;return m}
export function RY(a){let m=ident(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[2]=-s;m[8]=s;m[10]=c;return m}
export function RZ(a){let m=ident(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[1]=s;m[4]=-s;m[5]=c;return m}
export function compose(...ms){return ms.reduce(mul,ident())}
export function point(m,p){return [m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]]}
function perspective(f,a,n,z){let t=1/Math.tan(f/2);return new Float32Array([t/a,0,0,0,0,t,0,0,0,0,(z+n)/(n-z),-1,0,0,2*z*n/(n-z),0])}
function ortho(l,r,b,t,n,f){return new Float32Array([2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1])}
function look(eye,target,up=[0,0,1]){let z=V.norm(V.sub(eye,target)),x=V.norm(V.cross(up,z)),y=V.cross(z,x);return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-V.dot(x,eye),-V.dot(y,eye),-V.dot(z,eye),1])}
function normal(m){let a=[m[0],m[1],m[2]],b=[m[4],m[5],m[6]],c=[m[8],m[9],m[10]],bc=V.cross(b,c),ca=V.cross(c,a),ab=V.cross(a,b),d=V.dot(a,bc)||1;return new Float32Array([...bc.map(x=>x/d),...ca.map(x=>x/d),...ab.map(x=>x/d)])}
const vs=`#version 300 es
precision highp float;
layout(location=0) in vec3 aP;layout(location=1) in vec3 aN;
uniform mat4 uM,uVP,uLight;uniform mat3 uNormal;uniform vec3 uLocalScale;
out vec3 vN,vW,vMaterial;out vec4 vShadow;
void main(){vec4 p=uM*vec4(aP,1.);vW=p.xyz;vN=normalize(uNormal*aN);vMaterial=aP*uLocalScale;vShadow=uLight*p;gl_Position=uVP*p;}`;
const fs=`#version 300 es
precision highp float;
in vec3 vN,vW,vMaterial;in vec4 vShadow;out vec4 outColor;
uniform vec3 uColor,uEye;uniform float uMetal,uRough,uFloor,uSelected,uGrain;
uniform sampler2D uDepth;
const float PI=3.14159265;
float shadow(vec3 normal){
 vec3 p=vShadow.xyz/vShadow.w*.5+.5;
 if(p.z>1.||p.z<0.||p.x<0.||p.x>1.||p.y<0.||p.y>1.)return 1.;
 vec2 texel=1./vec2(textureSize(uDepth,0));
 float bias=max(.0008*(1.-dot(normal,normalize(vec3(-.5,-.6,1.)))),.00020);
 float sum=0.;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)sum+=p.z-bias<=texture(uDepth,p.xy+vec2(x,y)*texel*1.45).r?1.:0.;
 return sum/9.;
}
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
float hash(vec3 p){p=fract(p*.1031);p+=dot(p,p.yzx+33.33);return fract((p.x+p.y)*p.z);}
vec3 fresnel(float cosine,vec3 f0){return f0+(1.-f0)*pow(1.-clamp(cosine,0.,1.),5.);}
vec3 direct(vec3 n,vec3 view,vec3 l,vec3 color,float metal,float rough,vec3 f0){
 vec3 h=normalize(view+l);float ndl=max(dot(n,l),0.),ndv=max(dot(n,view),.001),ndh=max(dot(n,h),0.);
 float a=rough*rough,a2=a*a,den=ndh*ndh*(a2-1.)+1.;
 float D=a2/(PI*den*den+.0001),k=(rough+1.)*(rough+1.)/8.;
 float G=(ndv/(ndv*(1.-k)+k))*(ndl/(ndl*(1.-k)+k));
 vec3 F=fresnel(max(dot(h,view),0.),f0);
 vec3 spec=D*G*F/(4.*ndv*ndl+.001);
 return ((1.-F)*(1.-metal)*color/PI+spec)*ndl;
}
void main(){
 // All shipped meshes are closed solids. Do NOT flip normals on mirrored jaws.
 vec3 n=normalize(vN),view=normalize(uEye-vW),col=pow(uColor,vec3(2.2));
 float rough=clamp(uRough,.15,.94),metal=clamp(uMetal,0.,1.);
 if(uGrain>.5&&uFloor<.5){
  float line=sin(vMaterial.z*28.);float atten=1.-smoothstep(.1,.8,fwidth(vMaterial.z));
  float variation=(hash(floor(vMaterial*13.))-.5)*.025;
  col*=1.+variation+line*.017*atten;rough=clamp(rough+variation,.15,.95);
 }
 if(uFloor>.5){vec2 g=abs(fract((vW.xy+25.)/50.)-.5)/max(fwidth(vW.xy/50.),vec2(.0001));float line=1.-min(min(g.x,g.y),1.);col*=1.-line*.035;}
 vec3 f0=mix(vec3(.045),col,metal),key=normalize(vec3(-.5,-.6,1.));float sh=shadow(n);
 vec3 diffuse=col*(1.-metal)*(.32+.16*max(n.z,0.));
 vec3 result=diffuse+direct(n,view,key,col,metal,rough,f0)*3.4*(.30+.70*sh);
 result+=direct(n,view,normalize(vec3(.7,.4,.65)),col,metal,rough,f0)*1.05;
 vec3 ref=reflect(-view,n);float sky=.10+.38*smoothstep(-.3,.9,ref.z);
 float softbox=pow(max(dot(ref,normalize(vec3(-.25,-.5,.86))),0.),mix(85.,6.,rough));
 float sidebox=pow(max(dot(ref,normalize(vec3(.6,.5,.7))),0.),mix(70.,5.,rough));
 result+=fresnel(max(dot(n,view),0.),f0)*(vec3(sky)+vec3(1.,.96,.89)*softbox*.65+vec3(.83,.90,1.)*sidebox*.42);
 result+=col*.025*pow(1.-max(dot(n,view),0.),3.);
 result+=uSelected*vec3(.065,.033,.009);
 if(uFloor>.5){float haze=clamp(length(vW.xy)/3000.,0.,.7);result=mix(result,vec3(.52,.56,.61),haze);}
 outColor=vec4(pow(aces(result),vec3(1./2.2)),1.);
}`;
const dvs=`#version 300 es
precision highp float;layout(location=0) in vec3 aP;uniform mat4 uM,uVP;void main(){gl_Position=uVP*uM*vec4(aP,1.);}`;
const dfs=`#version 300 es
precision highp float;void main(){}`;
function program(gl,v,f){const sh=(t,s)=>{let q=gl.createShader(t);gl.shaderSource(q,s);gl.compileShader(q);if(!gl.getShaderParameter(q,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(q));return q};let p=gl.createProgram();gl.attachShader(p,sh(gl.VERTEX_SHADER,v));gl.attachShader(p,sh(gl.FRAGMENT_SHADER,f));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p}
export class Renderer{
constructor(canvas,meshes){this.canvas=canvas;const gl=this.gl=canvas.getContext('webgl2',{antialias:true,alpha:false,preserveDrawingBuffer:true});if(!gl)throw Error('WebGL 2 is unavailable. Enable hardware acceleration in your browser and reopen Seizo. No line-diagram fallback is used.');this.p=program(gl,vs,fs);this.sp=program(gl,dvs,dfs);this.loc={};for(let x of ['uM','uVP','uLight','uNormal','uColor','uEye','uMetal','uRough','uFloor','uSelected','uDepth','uGrain','uLocalScale'])this.loc[x]=gl.getUniformLocation(this.p,x);this.sloc={m:gl.getUniformLocation(this.sp,'uM'),vp:gl.getUniformLocation(this.sp,'uVP')};this.meshes={};for(let [k,v]of Object.entries(meshes))this.meshes[k]=this.mesh(v);this.parts=[];this.groups={};this.target=[95,0,208];this.az=-1.16;this.polar=.98;this.radius=835;this.selected='';this.hidden=new Set();this.dirty=true;this.frames=0;this.lastDraw=0;this.orbit=false;
this.light=mul(ortho(-550,650,-490,670,1,2100),look([-520,-640,1120],[85,0,150]));
this.depth=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,this.depth);gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,1024,1024,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);this.fb=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,this.fb);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,this.depth,0);gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Shadow framebuffer unavailable');gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.enable(gl.DEPTH_TEST);this.bindControls();new ResizeObserver(()=>this.dirty=true).observe(canvas);canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();document.dispatchEvent(new CustomEvent('studio-error',{detail:'3D graphics context paused by the browser. Reload to restore.'}))});}
mesh(d){const g=this.gl;let vao=g.createVertexArray();g.bindVertexArray(vao);for(let [i,a]of [[0,d.p],[1,d.n]]){let b=g.createBuffer();g.bindBuffer(g.ARRAY_BUFFER,b);g.bufferData(g.ARRAY_BUFFER,new Float32Array(a),g.STATIC_DRAW);g.enableVertexAttribArray(i);g.vertexAttribPointer(i,3,g.FLOAT,false,0,0);}g.bindVertexArray(null);return {vao,count:d.p.length/3,data:d}}
add(part){this.parts.push(part)}
bindControls(){let held=null;const c=this.canvas;c.oncontextmenu=e=>e.preventDefault();c.onpointerdown=e=>{held={x:e.clientX,y:e.clientY,pan:e.button===2||e.shiftKey,moved:false};c.setPointerCapture(e.pointerId)};c.onpointermove=e=>{if(!held)return;let dx=e.clientX-held.x,dy=e.clientY-held.y;held.moved|=Math.abs(dx)+Math.abs(dy)>1;if(held.pan){let a=this.az;this.target[0]+=(-Math.sin(a)*dx-Math.cos(a)*dy)*this.radius/900;this.target[1]+=(Math.cos(a)*dx-Math.sin(a)*dy)*this.radius/900;}else{this.az-=dx*.006;this.polar=Math.max(.04,Math.min(1.51,this.polar+dy*.006));}held.x=e.clientX;held.y=e.clientY;this.dirty=true};c.onpointerup=e=>{held=null};c.addEventListener('wheel',e=>{e.preventDefault();this.radius=Math.max(200,Math.min(2200,this.radius*Math.exp(e.deltaY*.001)));this.dirty=true},{passive:false});}
view(name){this.eyeOverride=null;if(name==='side'){this.target=[80,0,255];this.az=Math.PI/2;this.polar=1.42;this.radius=1050;}else if(name==='top'){this.target=[120,0,120];this.az=Math.PI;this.polar=.04;this.radius=900;}else if(name==='arm'){this.target=[135,0,153];this.az=1.1;this.polar=1.06;this.radius=625;}else{this.target=[90,0,240];this.az=1.16;this.polar=1.02;this.radius=1120;}this.dirty=true;}
render(force=false){if(document.hidden&&!force)return;if(!this.dirty&&!force)return;const now=performance.now();if(!force&&now-this.lastDraw<50)return;this.lastDraw=now;const g=this.gl,c=this.canvas,dpr=Math.min(window.devicePixelRatio||1,1.25);let w=Math.max(1,Math.floor(c.clientWidth*dpr)),h=Math.max(1,Math.floor(c.clientHeight*dpr));if(c.width!==w||c.height!==h){c.width=w;c.height=h}let fitRadius=this.radius*Math.max(1,1.1/(w/h));let eye=this.eyeOverride||[this.target[0]+fitRadius*Math.sin(this.polar)*Math.cos(this.az),this.target[1]+fitRadius*Math.sin(this.polar)*Math.sin(this.az),this.target[2]+fitRadius*Math.cos(this.polar)];this.eye=eye;this.vp=mul(perspective(.64,w/h,1,5000),look(eye,this.target));const rendered=[];for(let p of this.parts){if(this.hidden.has(p.category)||(p.group==='mast'&&this.hidden.has('camera'))||p.visible===false)continue;let group=this.groups[p.group]||ident(),m=mul(group,p.local);rendered.push([p,m])}
g.bindFramebuffer(g.FRAMEBUFFER,this.fb);g.viewport(0,0,1024,1024);g.clear(g.DEPTH_BUFFER_BIT);g.useProgram(this.sp);g.uniformMatrix4fv(this.sloc.vp,false,this.light);g.disable(g.CULL_FACE);for(let[p,m]of rendered){if(p.floor)continue;g.uniformMatrix4fv(this.sloc.m,false,m);let b=this.meshes[p.geometry];g.bindVertexArray(b.vao);g.drawArrays(g.TRIANGLES,0,b.count)}g.disable(g.CULL_FACE);
g.bindFramebuffer(g.FRAMEBUFFER,null);g.viewport(0,0,w,h);g.clearColor(.95,.96,.97,1);g.clear(g.COLOR_BUFFER_BIT|g.DEPTH_BUFFER_BIT);g.useProgram(this.p);g.uniformMatrix4fv(this.loc.uVP,false,this.vp);g.uniformMatrix4fv(this.loc.uLight,false,this.light);g.uniform3fv(this.loc.uEye,eye);g.activeTexture(g.TEXTURE0);g.bindTexture(g.TEXTURE_2D,this.depth);g.uniform1i(this.loc.uDepth,0);for(let[p,m]of rendered){g.uniformMatrix4fv(this.loc.uM,false,m);g.uniformMatrix3fv(this.loc.uNormal,false,normal(m));g.uniform3fv(this.loc.uColor,p.color);g.uniform1f(this.loc.uGrain,p.grain||0);g.uniform3fv(this.loc.uLocalScale,[Math.hypot(m[0],m[1],m[2]),Math.hypot(m[4],m[5],m[6]),Math.hypot(m[8],m[9],m[10])]);g.uniform1f(this.loc.uMetal,p.metal||0);g.uniform1f(this.loc.uRough,p.rough||.5);g.uniform1f(this.loc.uFloor,p.floor?1:0);g.uniform1f(this.loc.uSelected,this.selected===p.category?1:0);let b=this.meshes[p.geometry];g.bindVertexArray(b.vao);g.drawArrays(g.TRIANGLES,0,b.count)}g.bindVertexArray(null);this.dirty=false;this.frames++;}
screenRay(clientX,clientY){
 const rect=this.canvas.getBoundingClientRect();if(!this.eye||rect.width<1||rect.height<1)return null;
 const nx=2*(clientX-rect.left)/rect.width-1,ny=1-2*(clientY-rect.top)/rect.height;
 const forward=V.norm(V.sub(this.target,this.eye)),right=V.norm(V.cross(forward,[0,0,1])),up=V.cross(right,forward);
 const t=Math.tan(.64/2),aspect=rect.width/rect.height;
 return {origin:[...this.eye],direction:V.norm(forward.map((v,i)=>v+right[i]*nx*t*aspect+up[i]*ny*t))};
}
project(v){let a=this.vp;if(!a)return[0,0,false];let x=a[0]*v[0]+a[4]*v[1]+a[8]*v[2]+a[12],y=a[1]*v[0]+a[5]*v[1]+a[9]*v[2]+a[13],w=a[3]*v[0]+a[7]*v[1]+a[11]*v[2]+a[15];return[(x/w*.5+.5)*this.canvas.clientWidth,(-y/w*.5+.5)*this.canvas.clientHeight,w>0]}
}
