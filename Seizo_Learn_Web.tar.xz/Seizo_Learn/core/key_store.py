"""Version-independent, Windows-user-scoped Hack Club credential storage.

No plaintext fallback. Other operating systems remain session-only. The on-disk
schema/path/entropy are deliberately independent of the application folder and
release number, so compatible future builds can reuse the same secret.
"""
from __future__ import annotations

import ctypes
import hashlib
import os
from pathlib import Path
import tempfile
from typing import Protocol

MAGIC = b'SEIZO_PRIVATE_KEY_V1\n'
ENTROPY = b'Seizo/HackClubAI/credential/v1'
MAX_FILE = 65536


def private_root() -> Path:
    if os.name == 'nt':
        base = os.environ.get('LOCALAPPDATA')
        return (Path(base) if base else Path.home() / 'AppData' / 'Local') / 'Seizo'
    return Path.home() / '.local' / 'share' / 'Seizo'


def validate_key(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError('Paste the API key as text, not a command.')
    value = value.strip()
    if not 15 <= len(value) <= 2048 or any(ord(c) < 33 or ord(c) > 126 for c in value):
        raise ValueError('Copy the complete API key, without spaces, newlines or a Bearer prefix.')
    if value.startswith(('"', "'", '`')) or value.endswith(('"', "'", '`')):
        raise ValueError('Paste just the API key, without quotation marks.')
    return value


class Protector(Protocol):
    def protect(self, data: bytes) -> bytes: ...
    def unprotect(self, data: bytes) -> bytes: ...


class WindowsDPAPI:
    """Use CryptProtectData with current-user scope, never LOCAL_MACHINE."""
    def __init__(self):
        if os.name != 'nt':
            raise OSError('Windows DPAPI is unavailable on this operating system.')
        from ctypes import wintypes as w
        class Blob(ctypes.Structure):
            _fields_ = [('cbData', w.DWORD), ('pbData', ctypes.POINTER(ctypes.c_ubyte))]
        self.Blob = Blob
        self.crypt = ctypes.WinDLL('crypt32', use_last_error=True)
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.crypt.CryptProtectData.argtypes = [ctypes.POINTER(Blob), w.LPCWSTR,
            ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, w.DWORD, ctypes.POINTER(Blob)]
        self.crypt.CryptUnprotectData.argtypes = [ctypes.POINTER(Blob), ctypes.POINTER(w.LPWSTR),
            ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, w.DWORD, ctypes.POINTER(Blob)]
        self.crypt.CryptProtectData.restype = w.BOOL
        self.crypt.CryptUnprotectData.restype = w.BOOL
        self.kernel.LocalFree.argtypes = [ctypes.c_void_p]
        self.kernel.LocalFree.restype = ctypes.c_void_p

    def _blob(self, data: bytes):
        buf = ctypes.create_string_buffer(data, max(1, len(data)))
        return self.Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))), buf

    def _run(self, data: bytes, decrypt: bool) -> bytes:
        inp, keep = self._blob(data)
        entropy, keep_entropy = self._blob(ENTROPY)
        out = self.Blob()
        # 0x1 = CRYPTPROTECT_UI_FORBIDDEN. No machine-wide flag and no prompts.
        if decrypt:
            ok = self.crypt.CryptUnprotectData(ctypes.byref(inp), None, ctypes.byref(entropy),
                                               None, None, 0x1, ctypes.byref(out))
        else:
            ok = self.crypt.CryptProtectData(ctypes.byref(inp), 'Seizo Hack Club AI key',
                                             ctypes.byref(entropy), None, None, 0x1, ctypes.byref(out))
        try:
            if not ok:
                code = ctypes.get_last_error()
                raise OSError(f'Windows could not {"unlock" if decrypt else "protect"} the saved key (error {code}).')
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            if out.pbData:
                if decrypt:
                    ctypes.memset(out.pbData, 0, out.cbData)
                self.kernel.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))
            # Best effort for temporary C buffers; Python strings cannot be reliably wiped.
            ctypes.memset(ctypes.addressof(keep), 0, ctypes.sizeof(keep))
            ctypes.memset(ctypes.addressof(keep_entropy), 0, ctypes.sizeof(keep_entropy))

    def protect(self, data: bytes) -> bytes:
        return self._run(data, False)

    def unprotect(self, data: bytes) -> bytes:
        return self._run(data, True)


class KeyStore:
    def __init__(self, folder: Path | None = None, protector: Protector | None = None):
        self.path = (Path(folder) if folder is not None else private_root() / 'credentials') / 'hackclub.dpapi'
        self.warning = ''
        self.protector = protector
        if self.protector is None and os.name == 'nt':
            try:
                self.protector = WindowsDPAPI()
            except OSError:
                self.warning = 'Windows key protection could not initialize. No key will be saved unencrypted.'

    @property
    def supported(self) -> bool:
        return self.protector is not None

    def load(self) -> tuple[str, str]:
        if not self.supported:
            return '', ''
        try:
            with self.path.open('rb') as f:
                raw = f.read(MAX_FILE + 1)
        except FileNotFoundError:
            return '', ''
        if len(raw) > MAX_FILE or not raw.startswith(MAGIC):
            raise ValueError('Saved key file is invalid. Paste a replacement, or use Delete saved key.')
        try:
            secret = validate_key(self.protector.unprotect(raw[len(MAGIC):]).decode('utf-8'))
        except Exception:
            raise ValueError('Saved key could not be unlocked for this Windows user. Paste a replacement or delete it.') from None
        return secret, hashlib.sha256(raw).hexdigest()

    def save(self, key: str) -> tuple[str, str]:
        key = validate_key(key)
        if not self.supported:
            raise OSError('Permanent key storage requires Windows DPAPI. No plaintext key was written.')
        protected = self.protector.protect(key.encode('utf-8'))
        # Immediately verify that Windows can decrypt before committing to disk.
        if self.protector.unprotect(protected).decode('utf-8') != key:
            raise OSError('Saved-key verification failed; the previous saved key was not replaced.')
        raw = MAGIC + protected
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd, name = tempfile.mkstemp(prefix='.hackclub-', suffix='.tmp', dir=self.path.parent)
        try:
            with os.fdopen(fd, 'wb') as f:
                try:
                    os.chmod(name, 0o600)
                except OSError:
                    pass
                f.write(raw)
                f.flush()
                os.fsync(f.fileno())
            os.replace(name, self.path)
        finally:
            try:
                os.unlink(name)
            except FileNotFoundError:
                pass
        return key, hashlib.sha256(raw).hexdigest()

    def delete(self) -> None:
        # Never erase another application's files or revoke a provider credential.
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass
