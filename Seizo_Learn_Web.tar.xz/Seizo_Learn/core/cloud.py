"""Hack Club AI: optional *manual, text-only* semantic planner, virtual lab only.

Rules:
- fixed authenticated HTTPS host and endpoint; never an arbitrary URL/proxy
- API key is stored with current-user Windows DPAPI outside the app folder
- display only on explicit local Show; never in logs, reports or browser storage
- user clicks for each call; no autonomous cloud polling, coding agents, or reselling
- no live camera frames, personal data, motor commands, or device addresses sent
- this module only tests credentials; it never proposes or executes actions
- NEVER connects to hardware; this integration is *not* RL training.
"""
from __future__ import annotations
import http.client
import json
import re
import ssl
import time
from datetime import datetime, timezone
import threading
from .key_store import KeyStore, validate_key

HOST = 'ai.hackclub.com'
PATH = '/proxy/v1/chat/completions'
MODELS = (
    'qwen/qwen3-32b',
    'openai/gpt-oss-120b',
    'google/gemini-2.5-flash',
)
FAULTS = {'none','skip_step','marker_dropout','frozen_frame','camera_moved','reference_reset','stop','overheat'}


class HackClubPlanner:
    def __init__(self, api_key='', store=None):
        self._secret=''
        self._lock=threading.RLock()
        self._requests=0
        self._verified=False
        self._last_test=None
        self._revision=''
        self._storage_error=''
        self._busy=False
        self.store=store if store is not None else KeyStore()
        self._refresh_locked()
        if api_key:
            self.set_key(api_key)

    def _refresh_locked(self):
        if not self.store.supported:
            return
        try:
            secret, revision=self.store.load()
            if revision != self._revision:
                self._secret=secret
                self._revision=revision
                self._verified=False
                self._last_test=None
            self._storage_error=''
        except (ValueError,OSError):
            self._secret=''
            self._revision=''
            self._verified=False
            self._last_test=None
            self._storage_error='Saved key could not be read. Paste a replacement or use Delete saved key.'

    def set_key(self, api_key):
        key=validate_key(api_key)
        if not self._lock.acquire(blocking=False):
            raise ValueError('A key test is running. Wait for it to finish before replacing the key.')
        try:
            if self.store.supported:
                try:
                    secret, revision=self.store.save(key)
                except (OSError,ValueError):
                    raise ValueError('Key was NOT saved. Windows could not protect or write it. The previous saved key was kept.') from None
                self._secret=secret
                self._revision=revision
                message='Saved on this PC with Windows encryption. Compatible future Seizo versions will reuse it.'
            else:
                self._secret=key
                message='Session only on this operating system. Permanent storage requires Windows; no plaintext file was written.'
            self._storage_error=''
            self._verified=False
            self._last_test=None
        finally:
            self._lock.release()
        return {'ok':True,'enabled':True,'persisted':self.store.supported,'message':message}

    def clear_key(self):
        if not self._lock.acquire(blocking=False):
            raise ValueError('A key test is running. Wait for it to finish before deleting the key.')
        try:
            try:
                self.store.delete()
            except OSError:
                raise ValueError('The saved key file could not be deleted. No successful deletion is being claimed.') from None
            self._secret=''
            self._revision=''
            self._verified=False
            self._last_test=None
            self._storage_error=''
        finally:
            self._lock.release()
        return {'ok':True,'enabled':False,'persisted':False,
                'message':'Saved key deleted from this PC and cleared from this app. It is NOT revoked at Hack Club.'}

    def reveal_key(self):
        # The HTTP route must require an authenticated same-origin explicit POST.
        if not self._lock.acquire(blocking=False):
            raise ValueError('Wait for the key test to finish, then click Show.')
        try:
            self._refresh_locked()
            if self._storage_error:
                raise ValueError(self._storage_error)
            return {'key':self._secret,'enabled':bool(self._secret)}
        finally:
            self._lock.release()

    def status(self):
        acquired=self._lock.acquire(blocking=False)
        if acquired:
            try:self._refresh_locked()
            finally:self._lock.release()
        return {'enabled':bool(self._secret),'verified':self._verified,'name':'Hack Club AI',
                'models':list(MODELS),'requests_this_session':self._requests,
                'privacy':'Windows-user encrypted storage; reveal only by explicit local request. No images sent.',
                'storage_supported':self.store.supported,
                'persisted':bool(self._secret and self.store.supported),
                'storage_error':self._storage_error or self.store.warning,
                'busy':not acquired,
                'simulation_only':True,'physical_motion':False,'training_weights_updated':False,
                'last_connection_test':self._last_test}

    def test_connection(self, model='qwen/qwen3-32b'):
        """Verify this key and selected model with one small, manual cloud request.

        A successful HTTP response verifies the actual provider, not just that a
        pasted token looks plausible. Only counts/elapsed time enter the report.
        No scene, camera, local hardware or learned policy is consulted.
        """
        if model not in MODELS:
            raise ValueError('Select a supported Hack Club AI model.')
        if not self._lock.acquire(blocking=False):
            raise ValueError('Another Hack Club AI request is running. Wait until it finishes.')
        started=time.monotonic()
        try:
            self._refresh_locked()
            if not self._secret:
                raise ValueError('No API key is loaded. Paste and save a key above first.')
            self._last_test=None
            self._verified=False
            payload={
                'model': model,
                'messages':[{'role':'user','content':'Reply with exactly OK.'}],
                'stream':False,
                'temperature':0,
                'max_tokens':64,
            }
            conn=http.client.HTTPSConnection(HOST,timeout=25,context=ssl.create_default_context())
            try:
                conn.request('POST',PATH,
                    body=json.dumps(payload,separators=(',',':')).encode('utf-8'),
                    headers={'Authorization':'Bearer '+self._secret,
                             'Content-Type':'application/json',
                             'Accept':'application/json',
                             'Connection':'close'})
                response=conn.getresponse()
                status=response.status
                raw=response.read(50_001)
                if len(raw)>50_000:
                    raise ValueError('Hack Club returned an unusually large response.')
            except (OSError,TimeoutError,http.client.HTTPException):
                raise ValueError('Connection failed or timed out. Check internet and retry.') from None
            finally:
                conn.close()
            self._requests+=1
            if status!=200:
                errors={
                    400:'Hack Club rejected the test request. Try a different model.',
                    401:'API key rejected (401). Replace it or create a new key.',
                    402:'Daily Hack Club AI allowance reached (402). Try after the daily reset.',
                    403:'API access denied (403). Check your Hack Club account permissions.',
                    404:'Selected model or API endpoint not found (404). Try another model.',
                    429:'Hack Club is rate limiting this model (429). Wait and retry.',
                }
                raise ValueError(errors.get(status,f'Hack Club responded with HTTP {status}.'))
            data={}
            try:
                data=json.loads(raw)
                if not isinstance(data,dict):
                    raise ValueError('Invalid response format')
                choices=data.get('choices')
                if not isinstance(choices,list) or not choices:
                    raise ValueError('No model response')
                first=choices[0]
                if not isinstance(first,dict) or not isinstance(first.get('message'),dict):
                    raise ValueError('Invalid model message')
                content=first['message'].get('content')
                if content is not None and not isinstance(content,str):
                    raise ValueError('Invalid model content')
                raw_usage=data.get('usage',{})
                usage={k:raw_usage[k] for k in ('prompt_tokens','completion_tokens','total_tokens')
                       if isinstance(raw_usage,dict) and type(raw_usage.get(k)) is int}
            except (ValueError,TypeError,KeyError) as exc:
                raise ValueError('Hack Club responded, but the model reply could not be read. Try another model.') from None
            result={
                'connected':True,
                'key_accepted':True,
                'model_reachable':True,
                'model_responded':bool(content and content.strip()),
                'model':model,
                'elapsed_ms':round((time.monotonic()-started)*1000),
                'tested_utc':datetime.now(timezone.utc).isoformat(timespec='seconds'),
                'usage':usage,
                'weights_updated':False,
                'camera_images_sent':False,
                'motor_commands_sent':0,
                'physical_motion':False,
                'note':'One manual, small cloud test. No simulated learning or physical robot commands.',
            }
            self._verified=True
            self._last_test=result
            return result
        finally:
            self._lock.release()

