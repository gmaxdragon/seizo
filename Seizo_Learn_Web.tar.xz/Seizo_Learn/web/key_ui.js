// This local UI never reads the system clipboard. Only text pasted/typed into
// this field is submitted to the authenticated localhost server. No storage API.
export function setupKeyUI(api) {
  const $ = id => document.getElementById(id);
  const input=$('key'), status=$('keyStatus');
  let dirty=false, visible=false, saved=false, saving=false, testing=false;
  let timer=null, serial=Promise.resolve(), generation=0, seq=Date.now()*1000;
  let hydrated=false, pendingSaves=0;
  function message(text, error=false) { status.textContent=text; status.className=error?'error':''; }
  function controls() {
    $('keyTest').disabled=testing||saving;
    input.disabled=testing;
    $('keyToggle').disabled=testing;
    $('keySave').disabled=testing;
    $('keyForget').disabled=testing;
    $('keyToggle').textContent=visible?'Hide key':'Show key';
    $('keyToggle').setAttribute('aria-pressed',String(visible));
  }
  function hide() {
    visible=false; input.type='password';
    if (!dirty) input.value='';
    input.placeholder=saved?'Saved on this PC. Click Show key to view it.':'Paste your Hack Club API key';
    controls();
  }
  function enqueue(action) {
    const promise=serial.catch(()=>{}).then(action);
    serial=promise.catch(()=>{});return promise;
  }
  async function refresh() {
    try {
      const s=await api('/api/hackclub/status');
      saved=!!s.enabled;
      if (dirty||saving||testing) return;
      $('keyBadge').textContent=s.persisted?'Saved on this PC':saved?'Loaded for this session':'No key saved';
      if (s.storage_error) message(s.storage_error,true);
      else if(s.persisted) message(s.verified?'Saved on this PC. Hack Club accepted this key during this session.':'Saved key loaded automatically. Click Test key to check Hack Club.');
      else if(saved) message('Loaded for this session. Permanent encrypted storage is available on Windows only.');
      else message('Paste once. Windows will store it encrypted outside this download folder.');
      if(!visible) input.placeholder=saved?'Saved key loaded. Click Show key.':'Paste your Hack Club API key';
      hydrated=true;controls();
    } catch(e) { if(!dirty) message(e.message,true); }
  }
  function save() {
    clearTimeout(timer);
    const key=input.value.trim();
    if(!dirty&&saved) return serial;
    if(!key) { message('Paste a key first. Use Delete saved key to remove an existing one.',true); return Promise.resolve(false); }
    const id=++generation, mutation=++seq;
    pendingSaves++;saving=true;controls();message('Saving on this PC...');
    return enqueue(async()=>{
      try {
        const r=await api('/api/hackclub/key',{key,key_seq:mutation});
        if(id!==generation)return false;
        saved=true;dirty=false;
        $('keyBadge').textContent=r.persisted?'Saved on this PC':'Session only';
        message(r.message);
        if(!visible)input.value='';
        return true;
      } catch(e){if(id===generation){$('keyBadge').textContent='Not saved';message(e.message,true);}return false;}
      finally{pendingSaves--;saving=pendingSaves>0;controls();}
    });
  }
  input.addEventListener('input',()=>{
    dirty=true;generation++;clearTimeout(timer);
    // Never auto-reveal an existing saved key just because the page loaded.
    // New user-entered text stays visible so a bad paste can be spotted.
    visible=true;input.type='text';controls();
    $('keyBadge').textContent='Saving after paste';
    message('New key text entered. Saving automatically...');
    timer=setTimeout(save,700);
  });
  input.addEventListener('paste',()=>{ /* normal input event performs the save */ });
  $('keySave').onclick=()=>{void save();};
  input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();void save();}});
  $('keyToggle').onclick=async()=>{
    if(visible){hide();return;}
    if(dirty){visible=true;input.type='text';controls();return;}
    const id=generation;
    try {
      await serial;
      const r=await api('/api/hackclub/reveal',{confirmed:true});
      if(id!==generation)return;
      if(!r.enabled){message('No saved key. Paste a key into the field first.');return;}
      input.value=r.key;input.type='text';visible=true;controls();
      message('Key is visible on this screen. Hide it before sharing a screenshot.');
    }catch(e){message(e.message,true);}
  };
  $('keyForget').onclick=async()=>{
    clearTimeout(timer);const id=++generation, mutation=++seq;
    dirty=false;saved=false;input.value='';visible=false;input.type='password';pendingSaves++;saving=true;controls();
    message('Deleting the saved key from this PC...');
    await enqueue(async()=>{
      try {
        const r=await api('/api/hackclub/forget',{key_seq:mutation});
        if(id===generation){$('keyBadge').textContent='Deleted';message(r.message);hide();}
      }catch(e){if(id===generation){$('keyBadge').textContent='Delete failed';message(e.message,true);}}
      finally{pendingSaves--;saving=pendingSaves>0;controls();}
    });
  };
  $('keyTest').onclick=async()=>{
    clearTimeout(timer);
    if(dirty){const ok=await save();if(!ok)return;}
    await serial;testing=true;controls();
    message('Testing Hack Club over the internet. This does not train or move anything.');
    try {
      const r=await api('/api/hackclub/test',{model:$('keyModel').value});
      message(`Key accepted by Hack Club · ${r.elapsed_ms} ms · ${r.usage?.total_tokens??'unreported'} tokens. No weights updated.`);
      $('keyBadge').textContent='Connection passed';
    }catch(e){message(e.message,true);$('keyBadge').textContent='Test failed';}
    finally{testing=false;controls();}
  };
  // Hide secrets when this page leaves the foreground. This never deletes the key.
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&visible)hide();});
  controls();void refresh();
  return {refresh,hide,get hydrated(){return hydrated}};
}
