/* Shared kinematic specification, loaded from assets/kinematics.json.
 * Dragging and the renderer use this exact FK. Python reads the same JSON.
 * These checks protect a VIRTUAL PREVIEW, not a physical robot.
 */
export const DEG=Math.PI/180;
export let CONFIG=null;
export let DEFAULT_DIMS=null;
export let JOINT_LIMITS=null;
const JOINTS=['base','shoulder','forearm'];
const finite=n=>typeof n==='number'&&Number.isFinite(n);
export function configureKinematics(spec){
 if(!spec||!spec.model_id||!spec.dimensions||!spec.preview_limits_deg)throw Error('Incomplete shared geometry configuration.');
 for(const key of ['upper','forearm','shoulder_height','tool_length']){
  if(!finite(spec.dimensions[key])||spec.dimensions[key]<=0)throw Error('Invalid shared dimension '+key);
 }
 for(const key of JOINTS){const r=spec.preview_limits_deg[key];if(!Array.isArray(r)||r.length!==2||!r.every(finite)||r[0]>=r[1])throw Error('Invalid virtual joint limits.');}
 if(!finite(spec.tool_height_offset))throw Error('Invalid tool height offset.');
 CONFIG=JSON.parse(JSON.stringify(spec));
 DEFAULT_DIMS=Object.freeze({...CONFIG.dimensions});
 JOINT_LIMITS=Object.freeze(Object.fromEntries(JOINTS.map(k=>[k,Object.freeze([...CONFIG.preview_limits_deg[k]])])));
 return CONFIG;
}
function requireConfig(){if(!CONFIG)throw Error('Load shared geometry before building the arm.');}
export function fk(p,d=DEFAULT_DIMS){
 requireConfig();
 if(!p||JOINTS.some(k=>!finite(p[k])))throw Error('Finite virtual joint angles required.');
 const yaw=p.base*DEG,a=p.shoulder*DEG,b=p.forearm*DEG;
 const sh=[0,0,d.shoulder_height],e=[d.upper*Math.cos(a),0,d.shoulder_height+d.upper*Math.sin(a)];
 const w=[e[0]+d.forearm*Math.cos(b),0,e[2]+d.forearm*Math.sin(b)];
 const rot=v=>[v[0]*Math.cos(yaw)-v[1]*Math.sin(yaw),v[0]*Math.sin(yaw)+v[1]*Math.cos(yaw),v[2]];
 return {shoulder:rot(sh),elbow:rot(e),wrist:rot(w),tool:rot([w[0]+d.tool_length,0,w[2]+CONFIG.tool_height_offset])};
}
export function previewPoseCheck(p){
 requireConfig();
 if(!p||JOINTS.some(k=>!finite(p[k])))return {ok:false,reason:'Non-finite virtual joint pose.'};
 for(const key of JOINTS){const [lo,hi]=JOINT_LIMITS[key];if(p[key]<lo-1e-8||p[key]>hi+1e-8)return {ok:false,reason:key+' is outside its provisional preview range.'};}
 const k=fk(p),c=CONFIG.preview_clearance;
 if(k.wrist[2]<c.minimum_wrist_height-1e-7||k.elbow[2]<c.minimum_elbow_height-1e-7)return {ok:false,reason:'Target is below the provisional preview clearance.'};
 if(Math.hypot(k.wrist[0],k.wrist[1])<c.minimum_wrist_radius-1e-7)return {ok:false,reason:'Target enters the simplified base keep-out area.'};
 return {ok:true,reason:'Virtual preview only. Not a hardware safety check.'};
}
export function previewSweepCheck(from,to){
 for(let i=0;i<=32;i++){
  const p=Object.fromEntries(JOINTS.map(k=>[k,from[k]+(to[k]-from[k])*i/32]));
  const check=previewPoseCheck(p);if(!check.ok)return check;
 }
 return {ok:true,reason:'Sampled virtual joint path clear; full-mesh collision is not modeled.'};
}
const normalizeAngle=a=>((a+180)%360+360)%360-180;
export function solveToolTarget(target,seed){
 requireConfig();
 if(!Array.isArray(target)||target.length!==3||!target.every(finite))return {ok:false,reason:'Target must contain three finite model coordinates.'};
 if(!seed||JOINTS.some(k=>!finite(seed[k])))return {ok:false,reason:'No valid starting virtual pose.'};
 const d=DEFAULT_DIMS,r=Math.hypot(target[0],target[1])-d.tool_length;
 const z=target[2]-CONFIG.tool_height_offset-d.shoulder_height;
 const base=Math.atan2(target[1],target[0])/DEG;
 if(base<JOINT_LIMITS.base[0]-1e-8||base>JOINT_LIMITS.base[1]+1e-8)return {ok:false,reason:'Target exceeds the provisional base-rotation range.'};
 const cosine=(r*r+z*z-d.upper*d.upper-d.forearm*d.forearm)/(2*d.upper*d.forearm);
 if(cosine>1+1e-9||cosine< -1-1e-9)return {ok:false,reason:'Target is beyond the reconstructed linkage reach.'};
 const relative=Math.acos(Math.max(-1,Math.min(1,cosine)));
 let candidates=[],failure='Target cannot be reached within the provisional joint ranges.';
 for(const rel of [relative,-relative]){
  const a=Math.atan2(z,r)-Math.atan2(d.forearm*Math.sin(rel),d.upper+d.forearm*Math.cos(rel));
  const p={base,shoulder:normalizeAngle(a/DEG),forearm:normalizeAngle((a+rel)/DEG)};
  const check=previewPoseCheck(p);if(!check.ok){failure=check.reason;continue;}
  const sweep=previewSweepCheck(seed,p);if(!sweep.ok){failure=sweep.reason;continue;}
  const actual=fk(p).tool,error=Math.hypot(...actual.map((v,i)=>v-target[i]));
  if(error>0.001){failure='Inverse kinematics did not match the requested target.';continue;}
  candidates.push({ok:true,pose:p,tool:actual,error_mm:error,distance:JOINTS.reduce((v,k)=>v+(p[k]-seed[k])**2,0),reason:'Virtual target reached.'});
 }
 candidates.sort((a,b)=>a.distance-b.distance);
 return candidates[0]||{ok:false,reason:failure};
}
