No checkpoints shipped. Railway volume stores runtime policies.
